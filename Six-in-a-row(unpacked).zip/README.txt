A simple little game compiled with Qt(open source version for personal users) based on Dev-C++. This is just a basic project for personal practice and school homework. Inspired by the traditional five-in-a-row game, I apply a go board and a couple of free source material to manage this six-in-a-row game.

If you want to connect with me, here:
	github:	bearboy233-z
	mail:	897545282@qq.com

To reproduce or refer this project you shall indicate as below:
	source:	https://github.com/bearboy233-z/Six-in-a-row
	author:	bearboy233



ATTENTION:
Put the .sav files in an English path or you'll not be able to save/load the game correctly.